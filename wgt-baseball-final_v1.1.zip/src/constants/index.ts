export const SECRET_CODE_LENGTH = 3;
export const MAX_GUESSES = 10;
export const REWARD_AMOUNT = 10;